library(testthat)
library(airlines)

test_check("airlines")
